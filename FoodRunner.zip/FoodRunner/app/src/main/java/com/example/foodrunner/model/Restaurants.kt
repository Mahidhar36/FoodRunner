package com.example.foodrunner.model

 data class Restaurants (
     val restaurantId: Int,
    val restaurantName:String,
    val restaurantFoodCost:String,
    val restaurantRating:String,
    val restaurantImage:String
)