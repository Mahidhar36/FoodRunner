package com.example.foodrunner.model

data class RestaurantMenu (
    val ItemId:String,
    val ItemName:String,
    val cost_for_one:String,
    val RestaurantId:String
        )
